from flask import Flask, render_template, request
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')  # Update with your MongoDB connection string
db = client['hospital']  # Update with your database name
collection = db['details']  # Update with your collection name


@app.route('/')
def main():
    return render_template('main.html')


@app.route('/page', methods=['POST'])
def page():
    return render_template('example.html')


@app.route('/con', methods=['POST'])
def con():
    if request.method == 'POST':
        name = request.form['Name']
        gender = request.form['Gender']
        age = request.form['Age']
        dob = request.form['DOB']
        num = request.form['Number']
        doc = request.form['DOC']
        time = request.form['Time']

        # Save data to MongoDB
        data = {
            'Name': name,
            'Gender': gender,
            'Age': age,
            'DOB': dob,
            'Number': num,
            'DOC': doc,
            'Time': time
        }
        collection.insert_one(data)  # Insert data into MongoDB

        return render_template('confirm.html',n=name,g=gender,a=age,d=dob,nu=num,do=doc,t=time)


if __name__ == '__main__':
    app.run(debug=True)
