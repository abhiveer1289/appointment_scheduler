from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)


conn = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="ABHI@1289",
    database="appointments"
)
c = conn.cursor()


@app.route('/')
def main():
    return render_template('main.html')

@app.route('/dl', methods=['POST'])
def dl():
    return render_template('doc.html')
               
@app.route('/pl', methods=['POST'])
def pl():
    return render_template('pat.html')

@app.route('/page', methods=['POST'])
def page():
    return render_template('example.html')

@app.route('/con', methods=['POST'])
def con():
    if request.method == 'POST':
        name = request.form['name']
        gender = request.form['gender']
        age = request.form['age']
        dob = request.form['dob']
        num = request.form['phone']
        date=request.form['date']
        doc = request.form['doctor']
        time = request.form['time']
        query = "SELECT * FROM appointments WHERE doc=%s AND date=%s AND time=%s"
        values = (doc, date, time)
        c.execute(query, values)
        result = c.fetchone()
        if result:
            return render_template('fapp.html')

        c.execute("INSERT INTO appointments (name, gender, age, dob, number ,date, doc, time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                (name, gender, age, dob, num, date, doc, time))
        conn.commit()

        return render_template('done.html')

@app.route('/che', methods=['POST'])
def che():
    return render_template('checkk.html')

@app.route('/check', methods=['POST'])
def check():
    if request.method=='POST':
        date = request.form['date']
        doc = request.form['doctor']
        time = request.form['time']
    query = "SELECT time FROM appointments WHERE DOC=%s AND Date=%s AND Time=%s"
    values = (doc, date,time)
    c.execute(query, values)
    result = c.fetchone()
    if result:
            return render_template('fcheck.html')
    return render_template('pcheck.html')


@app.route('/log', methods=['POST'])
def log():
    if request.method == 'POST':
        id = request.form['ID']
        password = request.form['pass']
    i=id 
    p=password
    if i =='1111' and p=='1111':
        c.execute("SELECT * FROM appointments where doc='Dr.X Cardiologist';")
        appointments = c.fetchall()
        return render_template('search.html', appointments=appointments)
    elif i=='2222' and p=='2222':
        c.execute("SELECT * FROM appointments where doc='DR.Y ENT specialists';")
        appointments = c.fetchall()
        return render_template('search.html', appointments=appointments)
    elif i=='3333' and p=='3333':
        c.execute("SELECT * FROM appointments where doc='Dr.Z psychiatrists';")
        appointments = c.fetchall()
        return render_template('search.html', appointments=appointments)
    else:
        return render_template('fdoc.html')

@app.route('/see', methods=['POST'])
def see():
    if request.method == 'POST':
        id = request.form['thing']
    i=id
    c.execute("SELECT * FROM appointments WHERE Number=%s;", (i,))
    appointments = c.fetchall()
    return render_template('search.html', appointments=appointments)
@app.route('/search', methods=['GET', 'POST'])
def search():

        c.execute("SELECT * FROM appointments")
        appointments = c.fetchall()
        return render_template('search.html', appointments=appointments)

@app.route('/don', methods=['POST'])
def don():
    return render_template('done.html')

if __name__ == '__main__':
    app.run(debug=True)
