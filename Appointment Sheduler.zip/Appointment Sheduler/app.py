from flask import Flask,render_template,request
import sqlite3

app=Flask(__name__)

conn = sqlite3.connect('appointments.db')
c = conn.cursor()

@app.route('/')
def main():
    return render_template('main.html')

@app.route('/page', methods=['POST'])
def page():
    return render_template('example.html')


@app.route('/con', methods=['POST'])
def con():
    if request.method== 'POST':
        name=request.form['Name']
        gender=request.form['Gender']
        age=request.form['Age']
        dob=request.form['DOB']
        num=request.form['Number']
        doc=request.form['DOC']
        time=request.form['Time']
        return render_template('confirm.html',n=name,g=gender,a=age,d=dob,nu=num,do=doc,t=time)

if __name__=='__main__':
    app.run(debug=True)